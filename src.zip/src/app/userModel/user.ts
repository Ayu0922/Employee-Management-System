export class User {
    id:number=0;
    CompanyName:string='';
       JobRole:string='';
       Qulification:string='';
       Location:string='';
       Salary:number=0;
}
