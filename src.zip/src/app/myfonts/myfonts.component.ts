import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myfonts',
  templateUrl: './myfonts.component.html',
  styleUrls: ['./myfonts.component.css']
})
export class MyfontsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
