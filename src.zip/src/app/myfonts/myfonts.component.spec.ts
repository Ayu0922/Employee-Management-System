import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyfontsComponent } from './myfonts.component';

describe('MyfontsComponent', () => {
  let component: MyfontsComponent;
  let fixture: ComponentFixture<MyfontsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyfontsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyfontsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
